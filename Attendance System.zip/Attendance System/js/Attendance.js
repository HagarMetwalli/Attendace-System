class Attendance {
    constructor(_username, _min, _hour,_period, _day, _month, _attendcount, _absentcount, _latecount, _excuse, excuseflag) {
        this.username = _username,
            this.min = _min,
            this.hour = _hour,
            this.period = _period,
            this.day = _day,
            this.month = _month,
            this.attendcount = _attendcount,
            this.absentcount = _absentcount,
            this.latecount = _latecount,
            this.excuse = _excuse,
            this.excuseflag = excuseflag
       
    }
}
class EmpRepo {
    constructor(_fname, _lname, _hour, _min, _period, _username, _passwrd, _address, _email, _age, _empflag, _rondomcode, _attendcount, _absent, _latecount, _excuse) {
        this.fname = _fname,
            this.lname = _lname,
            this.username = _username,
            this.min = _min,
            this.hour = _hour,
            this.period = _period,
            this.password = _passwrd,
            this.address = _address,
            this.email = _email,
            this.age = _age,
            this.empflag = _empflag,
            this.rondomcode = _rondomcode
        this.attendcount = _attendcount,
            this.latecount = _latecount,
            this.absentcount = _absent,
            this.excuse = _excuse

    }
}
let emps=[];

class StoreEmployee {
    static getEmployee() {
        let employees;
        if (localStorage.getItem('Employees') === null) {
            employees = [];
        } else {
            employees = JSON.parse(localStorage.getItem('Employees'));
            emps = employees;
        }
        return employees; 
    }
    static getAttendance() {
        let Attendance;
        if (localStorage.getItem('Attendance') === null) {
            Attendance = [];
        } else {
            Attendance = JSON.parse(localStorage.getItem('Attendance'));
        }
        return Attendance;
    }
    static mergeEmpAttend(emps, attendArr) {
        //marge between Empolyees and Attendace Arrays into one array
        let newReoEmpobj = {};
        let EmpRepos = [];
        //localStorage.removeItem('mergeEmpAttend');
        emps.forEach((emp) => {
            attendArr.forEach((attendEmp) => {
                if (emp.username == attendEmp.username) {
                    newReoEmpobj = new EmpRepo(emp.fname, emp.lname, attendEmp.hour,
                        attendEmp.min, attendEmp.period, emp.username,
                        emp.password, emp.address, emp.email, emp.age, emp.Empflag, emp.rondomcode,
                        attendEmp.attendcount, attendEmp.absentcount, attendEmp.latecount, attendEmp.excuse); 

                }

            })
            EmpRepos.push(newReoEmpobj);
        })
        localStorage.setItem('mergeEmpAttend', JSON.stringify(EmpRepos));
  
        return EmpRepos
    }
    static addEmp(emp) {
        const employees = StoreEmployee.getEmployee();
        employees.push(emp);
        localStorage.setItem('Employees', JSON.stringify(employees));
    }

    static addAttend() {
        let i = 0;
        localStorage.removeItem('Attendance');
        let emps = StoreEmployee.getEmployee();
        console.log(emps);
        const attendent = StoreEmployee.getAttendance();
        emps.forEach((emp) => {
            i++;
            const newattend = new Attendance(emp.username, i+45, i+1,"PM",1,4,19+i,i+1,i+1,i,"False");
            attendent.push(newattend);
   
        });
        
        localStorage.setItem('Attendance', JSON.stringify(attendent));
    }


}
//UI class :Handle UI Tasks
class UI {
    static showAlert(massage, className) {
        const div = document.createElement('div');
        div.style.textAlign = 'center';
        div.className = 'alert alert-' + className;
        div.appendChild(document.createTextNode(massage));
        const container = document.querySelector('.container-fluid');
        console.log(container)
        const form = document.getElementById('formid');

        container.insertBefore(div, form);
        //Vanish in 3 seconds
        setTimeout(() => document.querySelector('.alert').remove(), 3000);
    }
    static removeElement(e) {
        if ((e.classList.contains('absent')) || (e.classList.contains('present'))) {
            e.parentElement.parentElement.remove();
            UI.showAlert('Done Successfully', 'success');

        }
    }
    static presentEmp(e) {
        if (e.classList.contains('present')) {
            e.parentElement.parentElement.remove();
            UI.showAlert('Employee Removed Successfully', 'success');
        }
    }
    static absentEmp(e) {
        if (e.classList.contains('absent')) {
            e.parentElement.parentElement.remove();
            UI.showAlert('Employee Removed Successfully', 'success');


        }
    }

}

var submitid = document.getElementById('submitid'); 
var userid = document.getElementById('userid');
let min, hour;
const empss = StoreEmployee.getEmployee();
const attendentcopy = StoreEmployee.getAttendance();
submitid.addEventListener('click', function (e) {
    e.preventDefault();
    //getDate and time
    let date = new Date();
    var flag = 0;
    //subAdmin attendance
    
    //employee attendance
    empss.forEach((emp) => {
        if (emp.rondomcode == userid.value) {
            attendentcopy.forEach((user) => {
                if (emp.username == user.username) {
                    flag = 1;
                    //console.log(emp.username);
                    user.min = date.getMinutes();
                    user.day = date.getDay();
                    user.month = 1;
                    user.hour = date.getHours();
                    if (user.hour >= 12) {
                        user.hour -= 12;
                        user.period = "PM";
                        
                    }
                    else if ((user.hour < 12)&&(user.hour > 10)) {
                        user.period = "AM";
                    }
                    else{
                        user.hour = "0" + user.hour;
                        user.period = "AM";
                    }
                    
                    if (user.min < 10) {
                        user.min = "0" + user.min;
                    }
                    if (user.excuseflag == "true") { user.excuse += 1; }
                    if ((user.hour >= 10)&&(user.period == "PM")){
                        user.absentcount += 1;
                       
                    }

                    else if ((user.hour == 9) && (user.min > 15) && (user.period == "PM")) {
                        user.latecount += 1;
                        
                    }
                    else if ((user.hour <= 9) && (user.period == "PM")) {
                        user.attendcount += 1;
                        console.log(user.attendcount)

                    }
                    else {
                        user.absentcount += 1;
                        localStorage.setItem('Attendance', JSON.stringify(attendentcopy));
                        console.log(user.attendcount)
                    }
                    localStorage.setItem('Attendance', JSON.stringify(attendentcopy));
                    UI.showAlert('Done Successfully', 'success');
                    //pass Data to anthor page
                    var attendData = [user.username, user.hour, user.min, user.period];
                    localStorage.setItem('EmployeeAttend', attendData);
                    window.open("displayattends.html",
                        `toolbar=no,
                    target=_blank,
                    location=no,
                    status=no,
                    menubar=no,
                    scrollbars=yes,
                    resizable=yes,
                    width=SomeSize,
                    height=SomeSize`);
                }
            })
        }      
    })
    StoreEmployee.mergeEmpAttend(empss, attendentcopy);
    userid.value = '';
    if (!flag) {
        UI.showAlert('The username for that code not exist', 'danger');
        userid.value = '';
    }
   
});

//console.log(attendentcopy)
//console.log(empss)


function SaveData() {

    //1- create blob
    var _StoreData = new Blob([JSON.stringify(attendentcopy)], { type: "appliction/json" });
    //2-create anchor
    var Linkelement = document.createElement("a");
    Linkelement.href = window.webkitURL.createObjectURL(_StoreData);
    Linkelement.setAttribute("download", "attendentceData.json");
    //append link
    document.body.appendChild(Linkelement);
    //click fire
    Linkelement.click();
    document.body.removeChild(Linkelement);
}
//SaveData();

