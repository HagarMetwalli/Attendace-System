class Employee{
    constructor(_fname, _lname, _username, _passwrd, _address, _email, _age, _empFlag,_rondomcode) {
            this.fname = _fname,
            this.lname = _lname,
            this.username = _username,
            this.password = _passwrd,
            this.address = _address,
            this.email = _email,
            this.age = _age,
            this.empflag = _empFlag,
            this.rondomcode = _rondomcode
    }
}
//Store Class :Handles Local Storage
let Emp;
class EmpRepo {
    constructor(_fname, _lname, _hour, _min, _period, _username, _passwrd, _address, _email, _age, _empflag, _rondomcode, _attendcount, _absent, _latecount, _excuse) {
        this.fname = _fname,
            this.lname = _lname,
            this.username = _username,
            this.min = _min,
            this.hour = _hour,
            this.period = _period,
            this.password = _passwrd,
            this.address = _address,
            this.email = _email,
            this.age = _age,
            this.empflag = _empflag,
            this.rondomcode = _rondomcode
            this.attendcount = _attendcount,
            this.latecount = _latecount,
            this.absentcount = _absent,
            this.excuse = _excuse

    }
}
class StoreEmployee {
    static getEmployee() {
        let employees;
        if (localStorage.getItem('Employees') === null) {
            employees = [];
        } else {
            employees = JSON.parse(localStorage.getItem('Employees'));
            Emp = employees;
        }
        return employees;
    }
    static addEmp(emp) {
        const employees = StoreEmployee.getEmployee();
        employees.push(emp);
        localStorage.setItem('Employees', JSON.stringify(employees));
        console.log(employees)
    }
    static removeEmp(email) {
        const employees = StoreEmployee.getEmployee();
        employees.forEach((emp, index) => {
            if (emp.email === email) {
                employees.splice(index, 1);
            }
        });
        localStorage.setItem('Employees', JSON.stringify(employees));
    }
}
class Attendance {
    constructor(_username, _min, _hour, _period, _day, _month, _attendcount, _absentcount, _latecount, _excuse, excuseflag) {
        this.username = _username,
            this.min = _min,
            this.hour = _hour,
            this.period = _period,
            this.day = _day,
            this.month = _month,
            this.attendcount = _attendcount,
            this.absentcount = _absentcount,
            this.latecount = _latecount,
            this.excuse = _excuse,
            this.excuseflag = excuseflag

    }
}
//UI class :Handle UI Tasks
class UI {
    static displayEmps() {
        const emps = StoreEmployee.getEmployee();
        emps.forEach((emp) => UI.addEmpFn(emp));
    }
    static addEmpFn(emp) {
        const tbl = document.getElementsByTagName('table')[0];
        const row = document.createElement('tr');
        row.innerHTML = `<td>${emp.f}</td><td>
            ${emp.lname}</td><td>${emp.address}</td ><td>${emp.email}</td >
            <td>${emp.age}</td >
            <td><a href="#" class="btn btn-Success btn-sm delete">Accept</a>
            <a href="#" class="btn btn-danger btn-sm delete">Refuse</a></td>`;
        tbl.appendChild(row);
    }
    static addAttend() {
        let i = 0;
        let attendent=[]
        localStorage.removeItem('Attendance');
        let emps = JSON.parse(localStorage.getItem('Employees'));
        emps.forEach((emp) => {
            i++;
            const newattend = new Attendance(emp.username, i + 45, i + 1, "PM", 1, 4, 19 + i, i + 1, i + 1, i, "False");
            attendent.push(newattend);

        });

        localStorage.setItem('Attendance', JSON.stringify(attendent));
    }
    static showAlert(massage, className) {
        const div = document.createElement('div');
        div.style.textAlign = 'center';
        div.className = 'alert alert-' + className;
        div.appendChild(document.createTextNode(massage));
        const container = document.querySelector('.container-fluid');
        console.log(container)
        const form = document.getElementById('formid');
        container.insertBefore(div, form);
        //Vanish in 3 seconds
        setTimeout(() => document.querySelector('.alert').remove(), 3000);
    }
    static clearinput() {
        document.getElementById('fnameid').value='';
        document.getElementById('lnameid').value = '';
        document.getElementById('userid').value = '';
        document.getElementById('passid').value = '';
        document.getElementById('addressid').value='';
        document.getElementById('emailid').value='';
        document.getElementById('ageid').value = '';
        

    }
    static removeElement(e) {
        if (e.classList.contains('delete')) {
            e.parentElement.parentElement.remove();
            UI.showAlert('Employee Removed Successfully', 'success');
        }
    }
    static randCode() {
        let rondcode = Math.floor(Math.random() * 1000);
        let arrrand = [];
        arrrand.push(rondcode);
        arrrand.forEach((code) => {
            if (rondcode == code)
                rondcode = Math.floor(Math.random() * 1000);
        });
    return rondcode;
    }
}
//ADD Admin for System
let admin = [{ "username": "Admin", "password": "ITI41" }];
localStorage.setItem('Admin', JSON.stringify(admin));

//read Data form json file and store in local Storage
let url = "DataSystem.json";
let Emparr = [];
let Attendarr = [];
let mergeArr = [];
function displayData(Data) {
    Data.forEach((emp) => {
        Emparr.push({
            "fname": emp.fname, "lname": emp.lname, "username": emp.username,
            "password": emp.password, "email": emp.email, "address": emp.address,
            "age": emp.age,
            "empflag": emp.empflag,
            "rondomcode": emp.rondomcode
        })
        Attendarr.push({
            "username": emp.username, "min": emp.min, "hour": emp.hour,
            "period": emp.period,
            "attendcount": emp.attendcount, "absentcount": emp.absentcount, "latecount": emp.latecount,
            "excuse": emp.excuse, "excuseflag": emp.excuseflag
        })
    })
    Emparr.forEach((emp) => {
        Attendarr.forEach((attendEmp) => {
            if (emp.username == attendEmp.username) {
                newReoEmpobj = new EmpRepo(emp.fname, emp.lname, attendEmp.hour,
                    attendEmp.min, attendEmp.period, emp.username,
                    emp.password, emp.address, emp.email, emp.age, emp.empFlag , emp.rondomcode,
                    attendEmp.attendcount, attendEmp.absentcount, attendEmp.latecount, attendEmp.excuse);
            }

        })
        mergeArr.push(newReoEmpobj);
        
    })
    console.log(Emparr)
    localStorage.setItem('Employees', JSON.stringify(Emparr));
    localStorage.setItem('Attendance', JSON.stringify(Attendarr));
    localStorage.setItem('mergeEmpAttend', JSON.stringify(mergeArr));
}
function getData() {
    let url = "js/Data.json";
    $.ajax({
        url: url,
        type: "get",
        data: { id: 101, "body": "Data System Request" },
        success: function (res) {
            displayData(res);
        },
        error: function (ErrorMessage) {
            console.log(ErrorMessage);
        }

    })


}
//load data for The frist Time
getData();
// Defining a function to validate form
var submit = document.getElementById('submitid');
submit.addEventListener('click', (e) => {
    e.preventDefault();
    
    const fname = document.getElementById('fnameid').value;
    const lname = document.getElementById('lnameid').value;
    const username = document.getElementById('userid').value;
    const pass = document.getElementById('passid').value;
    const address = document.getElementById('addressid').value;
    const email = document.getElementById('emailid').value;
    const age = document.getElementById('ageid').value;
    
    // document.getElementsByClassName('error')[0].style.display='none' ;
    

    var fnameErr = lnameErr = addressErr = emailErr = ageErr = userErr = passErr = true;
    if (fname === '' || username === '' || pass === '' || lname === '' || address === '' || email === '' || age === '')
    {

        UI.showAlert('please fill in all fields', 'danger');
    }

    else {
        const newRand = UI.randCode();
        const newEmp = new Employee(fname, lname, username, pass, address, email, age, "True", newRand);
        console.log(newEmp);


       StoreEmployee.addEmp(newEmp);
        //show success massage
        UI.showAlert('Employee Added Successfully', 'success');
        //Clear fields
        UI.clearinput();
    }
});


//Store data in json File
StoreEmployee.getEmployee();

function SaveData() {

    //1- create blob
    var _StoreData = new Blob([JSON.stringify(Emp)], { type: "appliction/json" });
    //2-create anchor
    var Linkelement = document.createElement("a");
    Linkelement.href = window.webkitURL.createObjectURL(_StoreData);
    Linkelement.setAttribute("download", "admin.json");
    //append link
    document.body.appendChild(Linkelement);
    //click fire
    Linkelement.click();
    document.body.removeChild(Linkelement);
}
//SaveData();
//const newEmp = new Employee("Ahmed", "Mohammed", "subAdmin41", "subAdmin@41", "31 Z. moaz St.", "subAdmin41@gmail.com", "25", "False",5000);
//StoreEmployee.addEmp(newEmp);
//const newEmp1 = new Employee("Heelan", "Ahmed", "Heelan41", "He@41", "11 Z. morad St.", "HeelanAh41@gmail.com", "22", "False", UI.randCode());
//StoreEmployee.addEmp(newEmp1);
//const newEmp2 = new Employee("Huda", "Ahmed", "Huda41", "Hu@41", "41 M. fahmy St.", "HudaAhm41@gmail.com", "23", "False", UI.randCode());
//StoreEmployee.addEmp(newEmp2);
//const newEmp3 = new Employee("Alaa", "Mohammed", "Alaa41", "Al@41", "23 M. road St.", "Alaamoh41@gmail.com", "19", "False", UI.randCode());

//UI.addAttend();
