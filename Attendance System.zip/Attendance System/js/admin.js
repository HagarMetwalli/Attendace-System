
class Admin {
    constructor( _username, _passwrd) {

        this.username = _username
        this.password = _passwrd;
    }
}
class EmpRepo {
    constructor(_fname, _lname, _hour, _min, _period, _username, _passwrd, _address, _email, _age, _empflag, _rondomcode, _attendcount, _absent, _latecount, _excuse) {
        this.fname = _fname,
            this.lname = _lname,
            this.username = _username,
            this.min = _min,
            this.hour = _hour,
            this.period = _period,
            this.password = _passwrd,
            this.address = _address,
            this.email = _email,
            this.age = _age,
            this.empflag = _empflag,
            this.rondomcode = _rondomcode
            this.attendcount = _attendcount,
            this.latecount = _latecount,
            this.absentcount = _absent,
            this.excuse = _excuse
            
    }
}
class Attendance {
    constructor(_username, _min, _hour, _period, _day, _month, _attendcount, _absentcount, _latecount, _excuse, excuseflag) {
        this.username = _username,
            this.min = _min,
            this.hour = _hour,
            this.period = _period,
            this.day = _day,
            this.month = _month,
            this.attendcount = _attendcount,
            this.absentcount = _absentcount,
            this.latecount = _latecount,
            this.excuse = _excuse,
            this.excuseflag = excuseflag

    }
}

class StoreEmployee {
    //add Employee in local Storage
    static addEmp(emp) {
        const employees = StoreEmployee.getEmployee();
        employees.push(emp);
        localStorage.setItem('Employees', JSON.stringify(employees));
    }
    //get Employee from local storage
    static getEmployee() {
        let employees;
        if (localStorage.getItem('Employees') === null) {
            employees = [];
        } else {
            employees = JSON.parse(localStorage.getItem('Employees'));
        }  
        return employees;
    }
    //remove Employee from local storage
    static removeEmp(email) {
        const employees = StoreEmployee.getEmployee();
        const attendentcopy = StoreEmployee.getAttendace();
        employees.forEach((emp, index) => {
            if (emp.email === email) {
                employees.splice(index, 1);
                attendentcopy.splice(index, 1);
                this.mergeEmpAttend(employees, attendentcopy);
            }
        });
        localStorage.setItem('Employees', JSON.stringify(employees));
        localStorage.setItem('Attendance', JSON.stringify(attendentcopy));
        localStorage.setItem('mergeEmpAttend', JSON.stringify(this.mergeEmpAttend(this.getEmployee(), this.getAttendace())));
    }

    //add attendance for Accepted Employee
    static addAttend(emp) {
        const attendent = StoreEmployee.getAttendace();
        const newattend = new Attendance(emp.username, 0, 0, "PM", 0, 0, 0, 0, 0, 0, "False");
        attendent.push(newattend);
        localStorage.setItem('Attendance', JSON.stringify(attendent));
    }

    //get attendance for Accepted Employee
    static getAttendace() {
        let attendace;
        if (localStorage.getItem('Attendance') === null) {
            attendace = [];
        } else {
            attendace = JSON.parse(localStorage.getItem('Attendance'));
        }
        return attendace;
    }

    //marge between Empolyees and Attendace Arrays into one array
    static mergeEmpAttend(emps, attendArr) {
        let newReoEmpobj = {};
        let EmpRepos = [];
        localStorage.removeItem('mergeEmpAttend'); 
        emps.forEach((emp) => {
            attendArr.forEach((attendEmp) => {
                if (emp.username == attendEmp.username) {
                    newReoEmpobj = new EmpRepo(emp.fname, emp.lname, attendEmp.hour,
                        attendEmp.min, attendEmp.period, emp.username,
                        emp.password, emp.address, emp.email, emp.age,emp.empflag, emp.rondomcode,
                        attendEmp.attendcount, attendEmp.absentcount, attendEmp.latecount, attendEmp.excuse);         
                }
               
            })
            EmpRepos.push(newReoEmpobj);
            console.log(newReoEmpobj)
        })
        localStorage.setItem('mergeEmpAttend', JSON.stringify(EmpRepos));
        return EmpRepos
    }

    //get merge array from local Storage
    static getmergeEmpAttend() {
        let EmpAttend;
        if (localStorage.getItem('Employees') === null) {
            EmpAttend = [];
        } else {
            EmpAttend = JSON.parse(localStorage.getItem('mergeEmpAttend'));
            
        }
        return EmpAttend;
    }

    //Accept new Employee
    static updateEmpflag(email) {
        console.log(email);
        const employees = StoreEmployee.getEmployee();
        employees.forEach((emp, index) => {
            if (emp.email === email) {
                emp.empflag = "False";
                this.addAttend(emp);
                this.mergeEmpAttend(this.getEmployee(), this.getAttendace());
            }
        });

        localStorage.setItem('Employees', JSON.stringify(employees));
    }
}
//UI class :Handle UI Tasks
class UI {
    //Add new employee request to UI
    static addEmpFn(emp) {
        const tbody = document.getElementById('emptbody');
        const row = document.createElement('tr');
        row.innerHTML = `<td>${emp.fname}</td><td>
            ${emp.lname}</td><td>${emp.address}</td >
            <td>${emp.age}</td ><td>${emp.email}</td >
            <td><button  class="btn btn-danger btn-sm delete">Remove</button></td>
            <td><button id="accept" class="btn btn-success btn-sm accept">Accept</button></td>`;
        tbody.appendChild(row);
    }
    //dispay Employee requests
    static displayEmps() {
        const emps = StoreEmployee.getEmployee();
        console.log(emps);
        for (let i = 1; i < emps.length; i++) { UI.addEmpFn(emps[i]) };
    }
    //Add new employee data to UI
    static addBrefEmpFn(emp) {
        const tbl = document.getElementById('brieftid');
        const row = document.createElement('tr');
        row.innerHTML = `<td>${emp.fname}</td><td>
            ${emp.lname}</td><td>${emp.address}</td>
            <td>${emp.age}</td><td>${emp.email}</td>
           <td>${emp.username}</td><td>${emp.password}</td>`
        tbl.appendChild(row);
    }
    //dispaly All Employees Data to UI
    static displayBrefEmp(emps) {
        emps.forEach((emp) => UI.addBrefEmpFn(emp));
    }

    //dispaly All Employee monthly reports to UI
    static fullReport(EmpAttend) {
        const tbody = document.getElementById('reptbody');
        EmpAttend.forEach((empRepo) => {
            const row = document.createElement('tr');
            row.innerHTML = `<td>${empRepo.fname} ${empRepo.lname}
                </td><td>${empRepo.attendcount}</td >
            <td>${empRepo.latecount}</td ><td>${empRepo.excuse}</td >`;
            tbody.appendChild(row);
        })

    }

    //dispaly All Employee daily reports to UI
    static DisplayDailyReport(dailyAttend) {
        const dailytbl = document.getElementById('repdailytbl');
        dailyAttend.forEach((emp) => {
            dailytbl.innerHTML += `<tr class="justify-content-center"><td>${emp.fname} ${emp.lname}</td><td>${emp.hour}:${emp.min} ${emp.period}</td></tr>`;

        })

    }
    //dispaly Alert
    static showAlert(massage, className) {
        const div = document.createElement('div');
        div.style.textAlign = 'center';
        div.className = 'alert alert-' + className;
        div.appendChild(document.createTextNode(massage));
        const container = document.querySelector('.container-fluid');
        console.log(container)
        const form = document.getElementById('formid');
        container.insertBefore(div, form);
        //Vanish in 3 seconds
        setTimeout(() => document.querySelector('.alert').remove(), 3000);
    }
    //remove employee from UI
    static removeElement(e) {
        if ((e.classList.contains('delete')) || (e.classList.contains('accept'))) {
            e.parentElement.parentElement.remove();
            UI.showAlert('Employee Removed Successfully', 'success');
        }
    }
    //accept employee 
    static acceptEmp(e) {
        if (e.classList.contains('accept')) {
            e.parentElement.parentElement.remove();
            UI.showAlert('Employee Added Successfully', 'success');

        }
    }

}
document.getElementById('emplistid').addEventListener('click', (e) => {
    //Event :Remove a Emp from UI
    UI.removeElement(e.target);
    //Event :Remove a Emp from Local storage
    StoreEmployee.removeEmp(e.target.parentElement.previousElementSibling.textContent);
    StoreEmployee.updateEmpflag(e.target.parentElement.previousElementSibling.previousElementSibling.textContent);
});


//Colling from local Storage
const emp = StoreEmployee.getEmployee();
const attendentcopy = StoreEmployee.getAttendace();
StoreEmployee.mergeEmpAttend(emp, attendentcopy);
console.log(StoreEmployee.mergeEmpAttend(emp, attendentcopy));
const mergEmpAttendvar = StoreEmployee.getmergeEmpAttend();


//UI.fullReport();

//Tabels IDS
const reptbl = document.getElementById('reptbl');
const dailytbl = document.getElementById('reptdailybl');
const emplistid = document.getElementById('emplistid');
const brieftid = document.getElementById('brieftid');
//Buttons IDs
const reqEmp = document.getElementById('empsid');
const reportsbtn = document.getElementById('reportsid');
const repdailybtn = document.getElementById('dailyid');
const briefidbtn = document.getElementById('briefidbtn');
const dailyid = document.getElementById('dailyid');
const savebtn = document.getElementById('savebtn');
//display Employees requests
let flag = flagd = 1;
reqEmp.addEventListener('click', function () {
    if (flagd) {
        emplistid.style.display = 'block';
        flagd = 0;
    }
    else {
        emplistid.style.display = 'none';
        flagd = 1;
    }
    if (flag) {
        UI.displayEmps();
        flag = 0;
    }  
});

//Display Monthly Employee Reports
let flagr = flagdr = 1;
reportsbtn.addEventListener('click', function () {
    if (flagdr) {
        reptbl.style.display = 'block';
        flagdr = 0;
    }
    else {
        reptbl.style.display = 'none';
        flagdr = 1;
    }
    if (flagr) {
        UI.fullReport(mergEmpAttendvar);
        flagr = 0;
    }

})

//Display Daily Employee Reports
let dailyr = dailydr = 1;
repdailybtn.addEventListener('click', function () {
    if (dailydr) {
        dailytbl.style.display = 'block';
        dailydr = 0;
    }
    else {
        dailytbl.style.display = 'none';
        dailydr = 1;
    }
    if (dailyr) {
        UI.DisplayDailyReport(mergEmpAttendvar);
        dailyr = 0;
    }

})

//Display all Employees
let flagb = flagdb = 1;
briefidbtn.addEventListener('click', function()
{
   
    if (flagdb) {
        brieftid.style.display = 'block';
        flagdb = 0;
    }
    else {
        brieftid.style.display = 'none';
        flagdb = 1;
    }
    if (flagb) {
        UI.displayBrefEmp(mergEmpAttendvar);
        flagb = 0;
    }


})
//Saving Data In Json File
savebtn.addEventListener('click', function(){ SaveData(mergEmpAttendvar);})
function SaveData(emps) {

    //1- create blob
    var _StoreData = new Blob([JSON.stringify(emps)], { type: "appliction/json" });
    //2-create anchor
    var Linkelement = document.createElement("a");
    Linkelement.href = window.webkitURL.createObjectURL(_StoreData);
    Linkelement.setAttribute("download", "DataSystem.json");
    //append link
    document.body.appendChild(Linkelement);
    //click fire
    Linkelement.click();
    document.body.removeChild(Linkelement);
}
