class Employee{
    constructor(_fname, _lname, _username, _passwrd, _address, _email, _age, _empflag,_rondomcode) {
            this.fname = _fname,
            this.lname = _lname,
            this.username = _username,
            this.password = _passwrd,
            this.address = _address,
            this.email = _email,
            this.age = _age,
            this.empflag = _empFlag,
            this.rondomcode = _rondomcode
    }
}

class EmployeeData {
    static addsubAdmin(emp) {
        let employee=[];
        employee.push(emp);
        localStorage.setItem('subAdmin', JSON.stringify(employee));
        console.log(emp)
    }
    static getEmpSData() {
        let employees;
        if (localStorage.getItem('mergeEmpAttend') === null) {
            employees = [];
        } else {
            employees = JSON.parse(localStorage.getItem('mergeEmpAttend'));
            
        }
        return employees;
    }

    static displayEmp(emp) {
        const tbl = document.getElementById('tbl');
        let empData = EmployeeData.getEmpSData();
        tbl.innerHTML = `<tr><th>Name</th><td>${emp.fname} ${emp.lname}</td></tr>
            <tr><th>Email</th><td>${emp.email}</td></tr>
            <tr><th>Adreess</th><td>${emp.address}</td></tr>
            <tr><th>Username</th><td>${emp.username}</td></tr>
            <tr><th>Password</th><td>${emp.password}</td></tr>`;
        
    }
    static DisplayDailyReport(emp) {
        const tblDaily = document.getElementById('dataid');
        tblDaily.innerHTML = `<tr><th>Name</th><td>${emp.fname} ${emp.lname}</td></tr>
            <tr><th>Attendance Time</th><td>${emp.hour}:${emp.min} ${emp.period}</td></tr>`;
    }
    static DisplayManthReport(emp) {
        console.log(emp)
        const tblDaily = document.getElementById('dataid');
        tblDaily.innerHTML = `<tr><th>Name</th><td>${emp.fname} ${emp.lname}</td></tr>
            <tr><th>Attendance Times</th><td>${emp.attendcount}</td></tr>
            <tr><th>Late Times</th><td>${emp.latecount}</td></tr> 
            <tr><th>Absence Times</th><td>${emp.absentcount}</td></tr>`;
    }

}
//get sign data Session
let userData = localStorage['SignEmp'];
let array = userData.split(',');
let _username = array[0];
let _password = array[1];
let Empattend;
//get Empolyee


const empData = EmployeeData.getEmpSData();
const subdmin = JSON.parse(localStorage.getItem('subAdmin'));

if ((empData[0].username == _username) && (empData[0].password == _password)) {
    document.getElementById("attendancebtn").style.display = 'block';
    EmployeeData.displayEmp(empData[0]);
    Empattend = empData[0];
}
else {
    empData.forEach((emp) => {
        if ((emp.username == _username) && (emp.password == _password)) {
            document.getElementById("attendancebtn").style.display = 'none';
            EmployeeData.displayEmp(emp);
            Empattend = emp;
        }
    })
}
console.log(Empattend)
//Display Employee Data

const dailybtn = document.getElementById('daily');
let flag=1;
document.getElementById('dataid').style.display = 'none';
dailybtn.addEventListener('click', function(){
    document.getElementById('dataid').style.display = 'block';
    if (flag) {
        EmployeeData.DisplayDailyReport(Empattend);
        flag = 0
    }
    else {
        document.getElementById('dataid').style.display = 'none';
        flag = 1;
    }
})
const mantlyhbtn = document.getElementById('monthly');
mantlyhbtn.addEventListener('click', function () {
    document.getElementById('dataid').style.display = 'block';
    if (flag) {
        EmployeeData.DisplayManthReport(Empattend);
        flag = 0
    }
    else {
        document.getElementById('dataid').style.display = 'none';
        flag = 1;
    }
})















