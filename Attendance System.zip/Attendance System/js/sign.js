class StoreEmployee {
    static getEmployee() {
        let employees;
        if (localStorage.getItem('Employees') === null) {
            employees = [];
        } else {
            employees = JSON.parse(localStorage.getItem('Employees'));
           // emps = employees;
            console.log(employees);
        }
        return employees;
    }

    static addEmp(emp) {
        const employees = StoreEmployee.getEmployee();
        employees.push(emp);
        localStorage.setItem('Employees', JSON.stringify(employees));
    }
    static removeEmp(email) {
        const employees = StoreEmployee.getEmployee();
        employees.forEach((emp, index) => {
            if (emp.email === email) {
                employees.splice(index, 1);
            }
        });
        localStorage.setItem('Employees', JSON.stringify(employees));
    }
    static signsession(user,pass) {
        let signEmp = [];
        localStorage.removeItem('SignEmp');
        signEmp.push(user);
        signEmp.push(pass);
        localStorage.setItem('SignEmp', signEmp); 
    }
    static updateEmpflag(email) {
        const employees = StoreEmployee.getEmployee();
        employees.forEach((emp, index) => {
            if (emp.email === email) {
                emp.empFlag = "False";
                console.log(emp.empFlag);
            }
        });

        localStorage.setItem('Employees', JSON.stringify(employees));
    }

}
//UI class :Handle UI Tasks
class UI {
    static displayEmps() {
        const emps = StoreEmployee.getEmployee();
        emps.forEach((emp) => UI.addEmpFn(emp));
    }
    static showAlert(massage, className) {
        const div = document.createElement('div');
        div.style.textAlign = 'center';
        div.className = 'alert alert-' + className;
        div.appendChild(document.createTextNode(massage));
        const container = document.querySelector('.container-fluid');
        //console.log(container)
        const form = document.getElementById('logid');

        container.insertBefore(div, form);
        //Vanish in 3 seconds
        setTimeout(() => document.querySelector('.alert').remove(), 3000);
    }
    static removeStyle() {
        $('#signid input').val('');
        $('#signid div').removeClass('help-block with-errors');
    }
    static checkUser() {
        let admin = [];
        let subAdmin = [];
        let employees = [];
        let flag = 1;
        admin = JSON.parse(localStorage.getItem('Admin'));
        employees = StoreEmployee.getEmployee();
        console.log(employees);
        const form = document.getElementById('signid');


        form.addEventListener('submit', function (event) {
            event.preventDefault();
            if (($('#userid').val() == '') || ($('#passid').val() == '')) {
                UI.showAlert('Please fill All fields', 'danger');
                UI.removeStyle();
            }
            if (($('#userid').val() == admin[0].username) && ($('#passid').val() == admin[0].password)) {
                //username =Admin,pass=ITI41
                this.action = 'Admin.html';
                this.submit();
                flag = 0;
            }

            if (($('#userid').val() == employees[0].username) && ($('#passid').val() == employees[0].password)) {
                let signEmp = [];
                localStorage.removeItem('SignEmp');
                StoreEmployee.signsession(employees[0].username, employees[0].password)
                this.action = 'employeeprofile.html';
                this.submit();
                flag = 0;
            }
            for (let i = 1; i < employees.length; i++) {
                console.log(employees);
                let emp = employees[i];
                if (($('#userid').val() == emp.username) && ($('#passid').val() == emp.password) && (emp.empflag == "False")) {
                    StoreEmployee.signsession(emp.username, emp.password)
                    this.action = 'employeeprofile.html';
                    this.submit();

                    flag = 0;

                }

            }
            if (flag) {
                UI.showAlert('You Entered In valid username or password', 'danger');
                UI.removeStyle();
            }


        })
    }
}
 UI.checkUser();
StoreEmployee.getEmployee();
//console.log(emps);
//emps.forEach((emp) => {
//    console.log(emp.fname)
//})